#!/bin/bash

mkdir sample-app
cd sample-app
sudo npm install